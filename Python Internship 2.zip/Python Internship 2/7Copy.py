from pymongo import MongoClient
from pymongo.server_api import ServerApi

client = MongoClient("mongodb+srv://Saurabhsm:saurabh@cluster1.whvbc.mongodb.net/?retryWrites=true&w=majority", server_api=ServerApi('1'))

db=client['office']
coll=db['workers']

pr={}
noo=input('Enter id of workers: ')
pr["_id"]=noo

for doc in coll.find(pr):
    print(doc)
    print()

db.exworkers.insert_one(doc)

db.workers.delete_one(doc)
print('Data deleted sucessfully')

