from pymongo import MongoClient
from pymongo.server_api import ServerApi

client = MongoClient("mongodb+srv://Saurabhsm:saurabh@cluster1.whvbc.mongodb.net/?retryWrites=true&w=majority", server_api=ServerApi('1'))


db=client['office']
coll=db['workers']

Ida=input('Enter id of workers: ')
nmp=input('Enter workers name: ')
dep=input('Enter department: ')
pos=input('Enter post: ')
cit=input('Enter city: ')
salc=int(input('Enter salary: '))
mbn=int(input('Enter mobile number: '))
emlm=input('Enter email: ')

dic={}
dic["_id"]=Ida
dic["empnm"]=nmp
dic["dept"]=dep
dic["post"]=pos
dic["city"]=cit
dic["salary"]=salc
dic["mobile"]=mbn
dic["email"]=emlm

db.workers.insert_one(dic)

print('Data added sucessfully')
