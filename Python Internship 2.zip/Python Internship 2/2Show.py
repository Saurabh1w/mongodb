from pymongo import MongoClient
from pymongo.server_api import ServerApi

client = MongoClient("mongodb+srv://Saurabhsm:saurabh@cluster1.whvbc.mongodb.net/?retryWrites=true&w=majority", server_api=ServerApi('1'))


db=client['office']
coll=db['workers']

for doc in coll.find():
    print(doc)
    print()