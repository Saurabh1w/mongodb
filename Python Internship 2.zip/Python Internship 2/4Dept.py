from pymongo import MongoClient
from pymongo.server_api import ServerApi

client = MongoClient("mongodb+srv://Saurabhsm:saurabh@cluster1.whvbc.mongodb.net/?retryWrites=true&w=majority", server_api=ServerApi('1'))

db=client['office']
coll=db['workers']

pr={}
dept=input('Enter Department: ')
pr["dept"]=dept

for doc in coll.find(pr):
    print(doc)
    print()


