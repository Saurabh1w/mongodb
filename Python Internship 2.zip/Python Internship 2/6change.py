from pymongo import MongoClient
from pymongo.server_api import ServerApi

client = MongoClient("mongodb+srv://Saurabhsm:saurabh@cluster1.whvbc.mongodb.net/?retryWrites=true&w=majority", server_api=ServerApi('1'))

db=client['office']
coll=db['workers']

pr={}
noo=input('Enter id of workers: ')
pr["_id"]=noo

ctt={}
tyc=input('Enter New City: ')
ctt["city"]=tyc

dept={}
mtc=input('Enter New Department: ')
dept["dept"]=mtc

updd={"$set":dept}
upd={"$set":ctt}
coll.update_many(pr,upd)
coll.update_many(pr,updd)
print('Doccument updated Successfully')
